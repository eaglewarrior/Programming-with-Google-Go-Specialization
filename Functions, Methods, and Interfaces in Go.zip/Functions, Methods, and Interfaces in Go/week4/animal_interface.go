package main

import (
  "bufio"
  "fmt"
  "strings"
  "os"
)

type Animal interface {
  Eat()
  Move()
  Speak()
}

type Cow struct {
  food string
  locomotion string
  noise string
}
func (c Cow) Eat() {
  fmt.Println("Cows eat", c.food)
}
func (c Cow) Move() {
  fmt.Println("Cows", c.locomotion)
}
func (c Cow) Speak() {
  fmt.Println("Cows", c.noise)
}

type Bird struct {
  food string
  locomotion string
  noise string
}
func (b Bird) Eat() {
  fmt.Println("Birds eat", b.food)
}
func (b Bird) Move() {
  fmt.Println("Birds", b.locomotion)
}
func (b Bird) Speak() {
  fmt.Println("Birds", b.noise)
}

type Snake struct {
  food string
  locomotion string
  noise string
}
func (s Snake) Eat() {
  fmt.Println("Snakes eat", s.food)
}
func (s Snake) Move() {
  fmt.Println("Snakes", s.locomotion)
}
func (s Snake) Speak() {
  fmt.Println("Snakes", s.noise)
}

func main() {
  var cows []string
  var birds []string
  var snakes []string

  for {
    reader := bufio.NewReader(os.Stdin)
    fmt.Print("> ")
    text, _ := reader.ReadString('\n')
    text = strings.TrimSuffix(text, "\n")
    user_in1 := strings.Split(text, " ")[0]
    user_in2 := strings.Split(text, " ")[1]
    user_in3 := strings.Split(text, " ")[2]

    if user_in1 == "newanimal" {

      if user_in3 == "cow" {
        var a1 Animal
        var c1 = Cow{"grass", "walk", "moo"}
        a1 = c1

        fmt.Println("Created it!", user_in2, a1)
        cows = append(cows, user_in2)
      } else if user_in3 == "bird" {
        var a1 Animal
        var c1 = Bird{"worms", "fly", "peep"}
        a1 = c1

        fmt.Println("Created it!", user_in2, a1)
        birds = append(birds, user_in2)
      } else if user_in3 == "snake" {
        var a1 Animal
        var c1 = Snake{"mice", "slither", "hsss"}
        a1 = c1

        fmt.Println("Created it!", user_in2, a1)
        snakes = append(snakes, user_in2)
      }
    }

    if user_in1 == "query" {

      for _, key := range cows {
        if key == user_in2 {
          fmt.Println("Found", user_in2)
          var a1 Animal
          var c1 = Cow{"grass", "walk", "moo"}
          a1 = c1
          if user_in3 == "eat" {
            a1.Eat()
          } else if user_in3 == "move" {
            a1.Move()
          } else if user_in3 == "speak" {
            a1.Speak()
          }
          break
        }
      }

      for _, key := range birds {
        if key == user_in2 {
          fmt.Println("Found", user_in2)
          var a1 Animal
          var c1 = Bird{"worms", "fly", "peep"}
          a1 = c1
          if user_in3 == "eat" {
            a1.Eat()
          } else if user_in3 == "move" {
            a1.Move()
          } else if user_in3 == "speak" {
            a1.Speak()
          }
          break
        }
      }

      for _, key := range snakes {
        if key == user_in2 {
          fmt.Println("Found", user_in2)
          var a1 Animal
          var c1 = Snake{"worms", "fly", "peep"}
          a1 = c1
          if user_in3 == "eat" {
            a1.Eat()
          } else if user_in3 == "move" {
            a1.Move()
          } else if user_in3 == "speak" {
            a1.Speak()
          }
          break
        }
      }
    }
  }
}