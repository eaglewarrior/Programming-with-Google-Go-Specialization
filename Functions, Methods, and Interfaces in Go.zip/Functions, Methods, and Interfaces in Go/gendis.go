package main

import (
	"fmt"
	"math"
)

func GenDisplaceFn(a, v, s float64) func(float64) float64 {
	fn := func(t float64) float64 {
		return (a*math.Pow(t, 2))/2 + v*t + s
	}
	return fn
}

func main() {
	var a, v, s, t float64
	fmt.Println("Enter acceleration, velocity, and initial displacement separated by spaces")
	fmt.Scan(&a, &v, &s)
	fn := GenDisplaceFn(a, v, s)
	fmt.Println("Enter time value")
	fmt.Scan(&t)
	fmt.Println(fn(t))

}