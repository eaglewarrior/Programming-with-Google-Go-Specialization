package main

import (
	"fmt"
	"log"
)

func main() {

	for {
		var animal, request string

		fmt.Println("Please enter animal: ")
		fmt.Printf("->")
		fmt.Scanln(&animal)

		fmt.Println("Please enter request: ")
		fmt.Printf("->")
		fmt.Scanln(&request)

		switch animal {
		case "snake":
			snake := Animal{
				food: "mice", locomotive: "slither", noise: "hsss",
			}
			snake.doAnimal(request)

		case "cow":
			cow := Animal{
				food: "grass", locomotive: "walk", noise: "moo",
			}
			cow.doAnimal(request)

		case "bird":
			bird := Animal{
				food: "worms", locomotive: "fly", noise: "peep",
			}
			bird.doAnimal(request)
		default:
			log.Println("such animal does not exist in the database")
		}
	}
}
func (a Animal) doAnimal(request string) {
	if request == "eat" {
		a.Eat()
	} else if request == "move" {
		a.Move()
	} else if request == "speak" {
		a.Speak()
	}
}

type Animal struct {
	food       string
	locomotive string
	noise      string
}

func (a Animal) Eat() {
	fmt.Println(a.food)
}
func (a Animal) Move() {
	fmt.Println(a.locomotive)
}
func (a Animal) Speak() {
	fmt.Println(a.noise)
}
