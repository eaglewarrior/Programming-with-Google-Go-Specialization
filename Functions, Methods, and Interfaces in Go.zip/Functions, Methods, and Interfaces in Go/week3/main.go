package main

import (
	"fmt"
	"reflect"
	"strings"
)
type Animal struct {
	food string
	locomotion string
	sound string
}

func (a Animal) Eat() {
	fmt.Println(a.food)
}
func (a Animal) Move() {
	fmt.Println(a.locomotion)
}
func (a Animal) Speak() {
	fmt.Println(a.sound)
}

func main() {
	cow := Animal{"grass", "walk", "moo"}
	bird := Animal{"worms", "fly", "peep"}
	snake := Animal{"mice", "slither", "hsss"}
	animalArr := [3]Animal{cow, bird, snake}
	indexMap := map[string]int{"cow": 0, "bird":1, "snake":2}

	for {
		var animal, option string
		fmt.Print("> ")
		fmt.Scan(&animal, &option)
		temp := &(animalArr[indexMap[animal]])
		reflect.ValueOf(temp).Elem().MethodByName(strings.Title(option)).Call([]reflect.Value{})
	}
}
