package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
)

func Swap(slc []int, i int) {
	slc[i], slc[i+1] = slc[i+1], slc[i]
}

func BubbleSort(slc []int) {
	for i := range slc[:len(slc)-1] {
		if slc[i] > slc[i+1] {
			Swap(slc, i)
		}
	}

}

func main() {
	reader := bufio.NewReader(os.Stdin)
	fmt.Printf("Enter integers (upto 10) separated by ' ' (space): ")
	line, err := reader.ReadString('\n')
	if err != nil {
		fmt.Println("Cant' read from StdIn. Exiting ...")
		os.Exit(0)
	}
	tokens := strings.Split(strings.TrimRight(line, "\n"), " ")
	if len(tokens) > 10 {
		fmt.Println("More than 10 integers entered. Exiting ...")
		os.Exit(0)
	}
	nums := make([]int, len(tokens))
	for i, t := range tokens {
		nums[i], _ = strconv.Atoi(t)
	}
	for i := 0; i < len(nums)-1; i++ {
		BubbleSort(nums[:len(nums)-i])
	}
	fmt.Println(nums)
}
