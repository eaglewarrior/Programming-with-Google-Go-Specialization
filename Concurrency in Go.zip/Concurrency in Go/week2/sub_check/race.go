package main

/*
In order to show the race condition we launch two goroutines
which just print input strings ("hello" and "world") 10 times
with a short sleep (100ms) on every iteration.

Because we can't predict the order of execution of instructions in
these goroutines, every programm run will show different output.
*/

import (
    "fmt"
    "sync"
    "time"
)

func say(wg *sync.WaitGroup, value string) {
    defer wg.Done()

    for i := 0; i < 10; i++ {
        fmt.Println(value)
        time.Sleep(100 * time.Millisecond)
    }
}

func main() {
    var wg sync.WaitGroup
    wg.Add(1)
    go say(&wg, "hello")
    wg.Add(1)
    go say(&wg, "world")
    wg.Wait()
}
