// RaceFactorSample.go
/*
The following code will exhibit how a race condition can happen due to
lack of syncronization between runing go routines including the main routine.

we started with x = 1
there is a go routine to increment x by 1 which cause x = 2 
another go routine to print x 
main routine also try to print x
*/
package main

import (
	"fmt"
)

var x int

func main() {

	x = 1 // initialize x
	go increment(&x)				// go routine to increment x by 1
	go printx(x)					// go routine to print x
	fmt.Println("x from main = ", x) // main routine to print x

}

func increment(i *int) {
	*i += 1
	fmt.Println("go routine add 1")
}

func printx(y int) {
	fmt.Println("x = ", y)
}
