package main

import (
  "fmt"
  "math/rand"
  "sync"
  "time"
)

type ChopS struct{ sync.Mutex }

type Philo struct {
  index int
  leftCS, rightCS *ChopS
}

func (p Philo) eat(wg *sync.WaitGroup, startEat chan int, doneEat chan int) {
  defer func() {
    doneEat <- 1
  }()
  defer wg.Done()

  <-startEat

  //pick chopstick
  p.leftCS.Lock()
  p.rightCS.Lock()

  fmt.Println("Philosopher", p.index, "starting to eat",)

  n := rand.Intn(3) + 1
  time.Sleep(time.Duration(n) * time.Second)

  fmt.Println("Philosopher", p.index, "finised eating in", n, "sec")

  //drop chopstick
  p.rightCS.Unlock()
  p.leftCS.Unlock()
}

func host(startEat chan int, doneEat chan int) {
  startEat <- 1
  startEat <- 1

  for {
    <-doneEat
    startEat <- 1
  }
}

func main() {
  CSticks := make([]*ChopS, 5)
  for i := 0; i < len(CSticks); i++ {
    CSticks[i] = new(ChopS)
  }

  philos := make([]*Philo, 5)
  for i := 0; i < len(philos); i++ {
    philos[i] = &Philo{i + 1, CSticks[i], CSticks[(i+1) % 5]}
  }

  startEat := make(chan int)
  doneEat := make(chan int)
  go host(startEat, doneEat)

  var wg sync.WaitGroup
  numEat := 0
  maxEat := 3
  for numEat < maxEat {
    for phi_idx := 0; phi_idx < len(philos); phi_idx++ {
      wg.Add(1)
      go philos[phi_idx].eat(&wg, startEat, doneEat)
    }
    numEat++
  }

  wg.Wait()
}