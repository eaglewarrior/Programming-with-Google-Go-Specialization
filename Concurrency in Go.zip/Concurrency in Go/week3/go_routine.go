package main

import (
        "bufio"
        "fmt"
        "os"
        "sort"
        "strconv"
        "strings"
)

func main() {
        c := make(chan []int, 4)
        fmt.Println("Input integers (seperate by space)")
        scanner := bufio.NewScanner(os.Stdin)
        scanner.Scan()
        inputs := strings.Fields(scanner.Text())
        sli := make([]int, 0)
        for _, el := range inputs {
                num, _ := strconv.Atoi(el)
                sli = append(sli, num)
        }
        subLen := len(sli) / 4
        sortSub(sli[0:subLen], c)
        sortSub(sli[subLen:2*subLen], c)
        sortSub(sli[2*subLen:3*subLen], c)
        sortSub(sli[3*subLen:], c)
        result := <-c
        for i := 0; i < 3; i++ {
                result = append(result, (<-c)...)
        }
        sort.Ints(result)
        fmt.Println(result)
}

func sortSub(sli []int, c chan []int) {
        fmt.Println(sli)
        sort.Ints(sli)
        c <- sli
}